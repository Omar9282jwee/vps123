See:
https://github.com/LMBishop/MoneyPouch/wiki/Custom-Economy-Types
